<link rel="icon" href="<?php echo e(asset('Logo.webp')); ?>" type="image/webp">
<?php /**PATH C:\laragon\www\SEO-HTML-Checker-main\resources\views/components/favicon.blade.php ENDPATH**/ ?>